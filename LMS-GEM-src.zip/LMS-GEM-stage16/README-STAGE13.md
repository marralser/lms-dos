# Stage 13 — Hercules display and compact player

Based on Stage 12. Changes:

* Player off/disconnected LED uses VDI palette index 8 (light grey) instead of red. Actual greyscale depends on the GEM display driver; some monochrome drivers map palette indices to only black/white. The other state colors remain unchanged.
* Removed album line and shifted player buttons upward one character row. Only artist - title remains.
* UTF-8: inspected original LMSDOS.CPP and LMSCORE.CPP; both only percent-decode LMS strings, neither implements UTF-8 to CP437/CP850 conversion. Added frontend ASCII transliteration for common accented Latin characters and punctuation, so GEM does not receive raw UTF-8 bytes. This deliberately sacrifices accents for legibility and is independent of GEM font encoding. Full CP850 mapping would require a font/driver-specific test.
* Clicking a displayed playlist song once now sends `playlist index N` using the absolute index (current index - 2 + visible row). Toolbar controls remain intact.

Build: `wmake clean` then `wmake` using the same GEMBIND and mTCP setup.

Not compiled or tested on Open Watcom 1.9 here. Verify LED shade on Hercules, narrow-window controls, UTF-8 strings, and playlist row clicks. Originals untouched.
