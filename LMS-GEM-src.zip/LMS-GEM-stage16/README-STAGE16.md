Stage 16: Playlist current song asterisk; Rand/- shuffle toggle; search selected category double border; library single-click activation. Build with wmake clean then wmake. Not locally compiled.
