LMS-GEM Stage 14
================
- Hercules-friendly LED: dark outlined ring when off, colored outlined ring when powered/paused, solid green when playing.
- Reduced player button height and gaps to make room for volume bar.
- Added GEM vertical scrollbars to Library and Playlist, including arrows, page scroll and draggable thumb.
- Playlist scrolling fetches only the eight visible titles on user scroll; no periodic list polling.
- Resource-free Desk / About menu adapted from Vocabula.
- About URL: https://github.com/marralser/lms-dos
- Requires GEMBIND and mTCP as previous stages. Build with wmake clean, wmake.
- Not compiled or run under Open Watcom 1.9 here.
