# LMS-GEM Stage 12 — Search

Based on Stage 11. The library toolbar S button is now labeled Add.
The library root includes Search below Genres. Select Search and activate
with Enter, >, or the second click. A small native GEM window asks for
search type (Song, Artist, Album, Genre) and text. Click a type and type
text, then press Enter to run the existing LMS CLI search and show the
results in the library pane. Escape cancels.

The search popup uses a resource-free VDI window, not a GEM RSC dialog.
The four category buttons are mouse-clickable; keyboard text entry uses
ASCII. Search is synchronous, as in the existing DOS controller.

Build: wmake clean && wmake (Open Watcom 1.9, GEMBIND and mTCP required).
Not compiled in the target DOS/OpenGEM environment.
