# LMS-GEM Stage 15

- Library toolbar now has eight buttons: Back, Enter, down 10, down 1, up 1, up 10, +, All.
- `+` invokes the existing browser add-only operation for the selected item (on Songs, adds just the selected song).
- `All` adds at most 40 songs from the current Songs view, starting with its first result. It is unavailable outside Songs, as before.
- Buttons are slightly narrower.
- About text includes: Thanks for using LMS-GEM, free to use and open source.
- The existing library scrollbar code is unchanged; actual display depends on the GEM window manager and window dimensions.
- Build with `wmake clean` then `wmake` using the same GEMBIND/mTCP setup. Not compiled here.
