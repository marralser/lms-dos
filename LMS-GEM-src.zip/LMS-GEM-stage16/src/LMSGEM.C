/* LMS-GEM stage 2: three native GEM windows with LMS-DOS backend. */
#include "ppdgem.h"
#include "LMSAPI.H"
#include <dos.h>
#include <stdio.h>
#include <string.h>
#define KIND (NAME|CLOSER|MOVER|SIZER|FULLER|VSLIDE|UPARROW|DNARROW)
#define SEG(p) FP_SEG(p)
#define OFF(p) FP_OFF(p)
typedef struct {WORD h,x,y,w,t;} PANE;
static PANE panes[3];static WORD vh,cw,ch,bw,bh,deskx,desky,deskw,deskh;
static int active=1,connected=0,running=1,ticks=0;
static int lib_top=0,queue_top=0;
static OBJECT menu_tree[14];
static char desk_title[]=" Desk ",about_title[]="  About LMS-GEM   ";
static char menu_sep[]="--------------------",menu_blank[]="                    ";

static char names[3][30]={"LMS - Player","LMS - Library / Favorites","LMS - Playlist"};
/* The same resource-free AES Desk menu construction used by Vocabula. */
static void menu_obj(WORD n,WORD next,WORD head,WORD tail,UWORD type,UWORD flags,
                     LPVOID spec,WORD x,WORD y,WORD w,WORD h){
 OBJECT *o=&menu_tree[n];o->ob_next=next;o->ob_head=head;o->ob_tail=tail;
 o->ob_type=type;o->ob_flags=flags;o->ob_state=NORMAL;o->ob_spec=spec;
 o->ob_x=x;o->ob_y=y;o->ob_width=w;o->ob_height=h;
}
static void setup_menu(WORD sw,WORD sh){WORD i;
 menu_obj(0,-1,1,4,G_IBOX,NONE,0L,0,0,80,25);
 menu_obj(1,4,2,2,G_BOX,NONE,(LPVOID)0x00001100L,0,0,80,0x0201);
 menu_obj(2,1,3,3,G_IBOX,NONE,0L,2,0,15,0x0301);
 menu_obj(3,2,-1,-1,G_TITLE,NONE,desk_title,0,0,6,0x0301);
 menu_obj(4,0,5,5,G_IBOX,NONE,0L,0,0x0301,80,23);
 menu_obj(5,4,6,13,G_BOX,NONE,(LPVOID)0x00ff1100L,2,0,20,8);
 menu_obj(6,7,-1,-1,G_STRING,NONE,about_title,0,0,20,1);
 menu_obj(7,8,-1,-1,G_STRING,NONE,menu_sep,0,1,20,1);
 for(i=8;i<14;i++)menu_obj(i,i==13?5:i+1,-1,-1,G_STRING,i==13?LASTOB:NONE,menu_blank,0,i-6,20,1);
 menu_tree[7].ob_state=DISABLED;menu_tree[13].ob_state=DISABLED;
 for(i=0;i<14;i++)rsrc_obfix(menu_tree,i);
 menu_tree[0].ob_width=sw;menu_tree[0].ob_height=sh;
 menu_tree[1].ob_width=sw;menu_tree[2].ob_width=sw-menu_tree[2].ob_x*2;
 menu_tree[4].ob_width=sw;menu_tree[4].ob_height=sh-menu_tree[4].ob_y;
}
static void show_about(void){
 form_alert(1,"[1][LMS-GEM for DOS GEM / OpenGEM|Lyrion Media Server controller|Thanks for using LMS-GEM,|free to use and open source|github.com/marralser/lms-dos][OK]");
}
static WORD maxi(WORD a,WORD b){return a>b?a:b;}
static WORD mini(WORD a,WORD b){return a<b?a:b;}
/* GEM bitmap fonts do not decode UTF-8. Convert common Latin characters
   to ASCII approximations before VDI; never pass UTF-8 continuation bytes. */
static void gem_text(const char *src,char *dst,unsigned cap){
 unsigned n=0; unsigned char c,d,e; const char *rep;
 while(*src && n+1<cap){
  c=(unsigned char)*src++;rep=0;
  if(c<128){dst[n++]=(c<32 && c!=9)?' ':c;continue;}
  d=(unsigned char)*src;
  if(c==0xC3 && d>=0x80 && d<=0xBF){
   ++src;
   if(d>=0x80&&d<=0x86)rep="A";
   else if(d==0x87)rep="C";
   else if(d>=0x88&&d<=0x8B)rep="E";
   else if(d>=0x8C&&d<=0x8F)rep="I";
   else if(d==0x91)rep="N";
   else if(d>=0x92&&d<=0x96)rep="O";
   else if(d>=0x99&&d<=0x9C)rep="U";
   else if(d==0x9D)rep="Y";
   else if(d==0x9F)rep="ss";
   else if(d>=0xA0&&d<=0xA6)rep="a";
   else if(d==0xA7)rep="c";
   else if(d>=0xA8&&d<=0xAB)rep="e";
   else if(d>=0xAC&&d<=0xAF)rep="i";
   else if(d==0xB1)rep="n";
   else if(d>=0xB2&&d<=0xB6)rep="o";
   else if(d>=0xB9&&d<=0xBC)rep="u";
   else if(d==0xBD||d==0xBF)rep="y";
  }else if(c==0xC5 && d){
   ++src;
   if(d==0x92)rep="OE";else if(d==0x93)rep="oe";
   else if(d==0x81)rep="L";else if(d==0x82)rep="l";
  }else if(c==0xE2 && d && src[1]){
   e=(unsigned char)src[1];
   if(d==0x80){src+=2;
    if(e==0x98||e==0x99)rep="'";
    else if(e==0x9C||e==0x9D)rep="\"";
    else if(e==0x93||e==0x94)rep="-";
    else if(e==0xA6)rep="...";
   }
  }
  if(!rep){
   /* Consume continuation bytes to avoid one question mark per byte. */
   while(((unsigned char)*src&0xC0)==0x80)++src;
   rep="?";
  }
  while(*rep && n+1<cap)dst[n++]=*rep++;
 }
 dst[n]=0;
}
static void put(WORD x,WORD y,const char *s){char clean[160];gem_text(s,clean,sizeof(clean));vst_color(vh,1);v_gtext(vh,x,y,clean);}
static void line(WORD x,WORD y,const char *s){put(x+6,y+ch+4,s);}
/* GEM VDI only: no bitmap assets or album-art decoding. */
#define PROGRESS_BLUE 1
#define BLACK 1
#define WHITE 0
#define CONTROL_COUNT 9
#define LED_OFF_GREY 0
#define LED_GREEN 3
#define LED_YELLOW 6
#define QUEUE_VISIBLE 8
#define QUEUE_BUTTONS 4
static const char *queue_buttons[QUEUE_BUTTONS]={"|<<",">>|","CLEAR","-"};
static int library_click_armed=-1;
#define LIB_TOOL_H (maxi(17,ch+4)*2+12)
#define NAV_COUNT 8
#define JUMP_COUNT 7
static const char *nav_label[NAV_COUNT]={"<",">","","","","","+","All"};
static const char *jump_label[JUMP_COUNT]={"A-C","D-F","G-I","J-L","M-O","Q-S","T-Z"};
static const char jump_letter[JUMP_COUNT]={'A','D','G','J','M','Q','T'};
static void library_click(WORD x,WORD y);
static void search_dialog(void);
static void repaint_pane(int n);
static void nav_arrow(WORD x,WORD y,WORD w,WORD h,int direction,int count);
static WORD ctl_x[CONTROL_COUNT],ctl_y,ctl_w,ctl_h;
static WORD bar_x,bar_y,bar_w,bar_h;
static WORD vol_x,vol_y,vol_w,vol_h;
static void fillrect(WORD x,WORD y,WORD w,WORD h,WORD color){
 WORD r[4];if(w<=0||h<=0)return;
 r[0]=x;r[1]=y;r[2]=x+w-1;r[3]=y+h-1;
 vsf_interior(vh,1);vsf_color(vh,color);v_bar(vh,r);
}
static void outline(WORD x,WORD y,WORD w,WORD h){
 WORD r[10];if(w<2||h<2)return;
 r[0]=x;r[1]=y;r[2]=x+w-1;r[3]=y;r[4]=x+w-1;
 r[5]=y+h-1;r[6]=x;r[7]=y+h-1;r[8]=x;r[9]=y;
 vsl_color(vh,BLACK);v_pline(vh,5,r);
}
/* Draw small GEM-native arrowheads. direction: -1 up, +1 down. */
static void nav_arrow(WORD x,WORD y,WORD w,WORD h,int direction,int count){
 WORD i,cy,xx,pts[6],spacing=5;
 xx=x+w/2;
 cy=y+h/2-(count-1)*spacing/2;
 vsl_color(vh,BLACK);
 for(i=0;i<count;i++){
  WORD tip=cy+(direction>0?3:-3);
  pts[0]=xx-4;pts[1]=cy-(direction>0?2:-2);
  pts[2]=xx;pts[3]=tip;
  pts[4]=xx+4;pts[5]=pts[1];
  v_pline(vh,3,pts);
  cy+=spacing;
 }
}
static void player_geometry(PANE *p){
 int i;WORD gap=3,usable;
 bar_x=p->x+8;bar_y=p->y+5;bar_w=p->w-16;bar_h=maxi(7,ch/2);
 ctl_y=p->y+bar_h+ch*2+12;ctl_h=maxi(14,ch+2);
 /* Reserve an LED gutter at the left, including white space. */
 usable=p->w-32-gap*(CONTROL_COUNT-1);ctl_w=usable/CONTROL_COUNT;
 if(ctl_w>56)ctl_w=56;
 if(ctl_w<12)ctl_w=12;
 for(i=0;i<CONTROL_COUNT;i++)ctl_x[i]=p->x+24+i*(ctl_w+gap);
 vol_x=p->x+8;vol_y=ctl_y+ctl_h+2;vol_w=p->w-16;vol_h=maxi(6,ch/3);
}
static void progress_bar(void){
 PANE *p=&panes[0];long pos,dur;WORD used;
 player_geometry(p);
 if(bar_w<=0||bar_y+bar_h>p->y+p->t)return;
 pos=connected?lg_position():0;dur=connected?lg_duration():0;
 if(pos<0)pos=0;
 if(dur>0&&pos>dur)pos=dur;
 used=(dur>0)?(WORD)((pos/dur)*bar_w+((pos%dur)*bar_w)/dur):0;
 fillrect(bar_x,bar_y,bar_w,bar_h,WHITE);
 if(used>0)fillrect(bar_x,bar_y,used,bar_h,PROGRESS_BLUE);
 outline(bar_x,bar_y,bar_w,bar_h);
}
/* A VDI filled circle, independent of fonts and code pages. */
/* Outline-only LED for standby, solid LED for playback; works on Hercules. */
static void player_led(void){
 WORD cx,cy,rad,playing=0;
 player_geometry(&panes[0]);
 rad=maxi(2,mini(ctl_h/4,5));cx=ctl_x[0]-rad-5;cy=ctl_y+ctl_h/2;
 playing=(WORD)(connected && lg_power() && strcmp(lg_mode(),"play")==0);
 vsf_interior(vh,1);vsf_color(vh,WHITE);v_circle(vh,cx,cy,rad);
 if(playing){vsf_color(vh,LED_GREEN);v_circle(vh,cx,cy,rad);}
 else if(connected && lg_power()){
  vsl_color(vh,LED_GREEN);v_circle(vh,cx,cy,rad); /* overwritten below by outline */
  vsf_color(vh,WHITE);v_circle(vh,cx,cy,maxi(1,rad-2));
  vsl_color(vh,LED_GREEN);
 }else{
  vsf_color(vh,BLACK);v_circle(vh,cx,cy,rad);
  vsf_color(vh,WHITE);v_circle(vh,cx,cy,maxi(1,rad-2));
 }
}
static void stop_symbol(void){
 WORD size=maxi(5,mini(ctl_w,ctl_h)/3);
 WORD x=ctl_x[3]+(ctl_w-size)/2;
 WORD y=ctl_y+(ctl_h-size)/2;
 fillrect(x,y,size,size,BLACK);
}
static void draw_button(int i,const char *caption){
 WORD x=ctl_x[i],y=ctl_y;
 if(x+ctl_w>panes[0].x+panes[0].w||y+ctl_h>panes[0].y+panes[0].t)return;
 fillrect(x,y,ctl_w,ctl_h,WHITE);outline(x,y,ctl_w,ctl_h);
 put(x+maxi(2,(ctl_w-(WORD)strlen(caption)*cw)/2),y+ctl_h/2+ch/3,caption);
}
/* Compact modal search popup: no RSC file or DOS console input required.
   Uses GEM window + VDI and keyboard events; redraws on exposure. */
static void search_dialog(void){
 static const char *types[4]={"Song","Artist","Album","Genre"};
 WORD handle,wx,wy,ww,wh,x,y,w,h,ev,msg[8],r[4];
 UWORD mx,my,mb,ks,key,clicks;
 char query[48],label[80];
 int kind=0,len=0,done=0,accept=0,ascii;
 wx=deskx+deskw/8;wy=desky+deskh/4;ww=deskw*3/4;wh=maxi(105,ch*7+28);
 handle=wind_create(NAME|MOVER,deskx,desky,deskw,deskh);
 if(handle<0){form_alert(1,"[1][Cannot open search window][OK]");return;}
 wind_set(handle,WF_NAME,OFF("LMS Search"),SEG("LMS Search"),0,0);
 wind_open(handle,wx,wy,ww,wh);
 wind_get(handle,WF_WORKXYWH,&x,&y,&w,&h);
 query[0]=0;
 while(!done){
  WORD bx=x+8,by=y+ch+8,bw=(w-16)/4,i;
  r[0]=x;r[1]=y;r[2]=x+w-1;r[3]=y+h-1;vs_clip(vh,1,r);
  fillrect(x,y,w,h,WHITE);
  put(x+8,y+ch,"Search category (click or keys 1-4):");
  for(i=0;i<4;i++){
   WORD xx=bx+i*bw;
   fillrect(xx,by,bw-3,maxi(ch+6,18),WHITE);outline(xx,by,bw-3,maxi(ch+6,18));
   if(i==kind){outline(xx+1,by+1,bw-5,maxi(ch+6,18)-2);outline(xx+2,by+2,bw-7,maxi(ch+6,18)-4);}
   put(xx+4,by+ch+2,types[i]);
  }
  sprintf(label,"Text: %.45s_",query);put(x+8,by+ch*3+9,label);
  put(x+8,by+ch*5+10,"Enter = Search     Esc = Cancel");
  vs_clip(vh,0,r);
  ev=evnt_multi(MU_KEYBD|MU_BUTTON|MU_MESAG,1,1,1,
   0,0,0,0,0,0,0,0,0,0,msg,0,0,&mx,&my,&mb,&ks,&key,&clicks);
  if(ev&MU_KEYBD){
   ascii=key&255;
   if(ascii==27)done=1;
   else if(ascii==13){if(len){accept=1;done=1;}}
   else if(ascii==8){if(len)query[--len]=0;}
   else if(ascii>=32&&ascii<=126&&len<(int)sizeof(query)-1){
    query[len++]=(char)ascii;query[len]=0;
   }
  }
  if(ev&MU_BUTTON){
   if(my>=by&&my<by+maxi(ch+6,18)&&mx>=bx&&mx<bx+4*bw)
    kind=(mx-bx)/bw;
  }
  if(ev&MU_MESAG){
   if(msg[0]==WM_CLOSED&&msg[3]==handle)done=1;
   if(msg[0]==WM_MOVED&&msg[3]==handle){
    wind_set(handle,WF_CURRXYWH,msg[4],msg[5],msg[6],msg[7]);
    wind_get(handle,WF_WORKXYWH,&x,&y,&w,&h);
   }
  }
 }
 wind_close(handle);wind_delete(handle);
 if(accept){
  if(lg_browser_search(kind,query)!=0)form_alert(1,"[1][Search failed][OK]");
  library_click_armed=-1;repaint_pane(1);
 }else repaint_pane(1);
}
static void volume_bar(void){
 WORD used,vol=connected?lg_volume():0;
 if(vol<0)vol=0;if(vol>100)vol=100;
 if(vol_w<10||vol_y+vol_h>panes[0].y+panes[0].t)return;
 used=(WORD)((long)(vol_w-38)*vol/100);
 put(vol_x,vol_y+vol_h+ch/3,"VOL");
 fillrect(vol_x+34,vol_y,vol_w-34,vol_h,WHITE);
 if(used>0)fillrect(vol_x+34,vol_y,used,vol_h,PROGRESS_BLUE);
 outline(vol_x+34,vol_y,vol_w-34,vol_h);
}
static int library_visible(PANE *p){int n=(p->t-LIB_TOOL_H-ch*2-4)/ch;return n<1?1:(n>10?10:n);}
static int queue_visible(PANE *p){int n=(p->t-maxi(18,ch+6)-6-ch*2-4)/ch;return n<1?1:(n>QUEUE_VISIBLE?QUEUE_VISIBLE:n);}
static void update_slider(int n){
 int total,visible,maxoff,off,size,pos;
 PANE *p=&panes[n];
 if(n==0)return;
 total=n==1?lg_browser_count():lg_queue_count();
 visible=n==1?library_visible(p):queue_visible(p);
 maxoff=maxi(0,total-visible);
 off=n==1?lib_top:queue_top;if(off>maxoff)off=maxoff;if(off<0)off=0;
 if(n==1)lib_top=off;else queue_top=off;
 size=total>0?(int)((long)visible*1000/total):1000;if(size>1000)size=1000;
 pos=maxoff>0?(int)((long)off*1000/maxoff):0;
 wind_set(p->h,WF_VSLSIZE,size,0,0,0);
 wind_set(p->h,WF_VSLIDE,pos,0,0,0);
}
static void scroll_pane(int n,int delta){
 int maxoff,visible,total,*top;
 if(n==1){top=&lib_top;total=lg_browser_count();visible=library_visible(&panes[1]);}
 else{top=&queue_top;total=lg_queue_count();visible=queue_visible(&panes[2]);}
 maxoff=maxi(0,total-visible);*top+=delta;
 if(*top<0)*top=0;if(*top>maxoff)*top=maxoff;
 if(n==2)lg_queue_window(*top);
 update_slider(n);repaint_pane(n);
}
static void render(int n){
 PANE *p=&panes[n];WORD a[4];int i;char b[110];WORD y;
 wind_get(p->h,WF_WORKXYWH,&p->x,&p->y,&p->w,&p->t);
 a[0]=p->x;a[1]=p->y;a[2]=p->x+p->w-1;a[3]=p->y+p->t-1;
 vsf_interior(vh,1);vsf_color(vh,WHITE);v_bar(vh,a);
 if(n==0){
  player_geometry(p);progress_bar();
  sprintf(b,"%.43s - %.54s",connected?lg_artist():"--",connected?lg_title():"--");
  line(p->x,p->y+bar_h+5,b);
  draw_button(0,"P");draw_button(1,"|<<");
  draw_button(2,connected&&strcmp(lg_mode(),"play")==0?"||":">");
  draw_button(3,"");stop_symbol();draw_button(4,">>|");draw_button(5,"OFF");
  draw_button(6,"V-");draw_button(7,"V+");
  draw_button(8,connected?(lg_repeat_mode()==1?"SnG":lg_repeat_mode()==2?"PLS":"/"):"/");
  player_led();
  volume_bar();
 }else if(n==1){
  WORD bx=p->x+6, by=p->y+4, bh=maxi(17,ch+4);
  WORD button_w, gap=2, xx;
  /* Eight compact navigation buttons, then seven alphabetic jump buttons. */
  button_w=(p->w-12-gap*(NAV_COUNT-1))/NAV_COUNT;
  if(button_w>40)button_w=40;
  if(button_w<10)button_w=10;
  for(i=0;i<NAV_COUNT;i++){
   xx=bx+i*(button_w+gap);
   if(xx+button_w>p->x+p->w)break;
   fillrect(xx,by,button_w,bh,WHITE);outline(xx,by,button_w,bh);
   if(i>=2&&i<=5){
    nav_arrow(xx,by,button_w,bh,(i==2||i==3)?1:-1,(i==2||i==5)?2:1);
   }else{
    put(xx+maxi(1,(button_w-(WORD)strlen(nav_label[i])*cw)/2),by+bh/2+ch/3,nav_label[i]);
   }
  }
  button_w=(p->w-12-gap*(JUMP_COUNT-1))/JUMP_COUNT;
  if(button_w>48)button_w=48;
  if(button_w<12)button_w=12;
  for(i=0;i<JUMP_COUNT;i++){
   xx=bx+i*(button_w+gap);
   if(xx+button_w>p->x+p->w)break;
   fillrect(xx,by+bh+4,button_w,bh,WHITE);outline(xx,by+bh+4,button_w,bh);
   put(xx+maxi(1,(button_w-(WORD)strlen(jump_label[i])*cw)/2),by+bh+4+bh/2+ch/3,jump_label[i]);
  }
  sprintf(b,"%.64s",connected?lg_browser_title():"Library (not connected)");
  line(p->x,p->y+LIB_TOOL_H,b);
  for(i=0;i<(connected?lg_browser_count()-lib_top:0)&&i<library_visible(p);i++){
   y=p->y+LIB_TOOL_H+ch*(i+2);if(y+ch>p->y+p->t)break;
   sprintf(b,"%c %.66s",lg_browser_selected()==i+lib_top?'>':' ',lg_browser_item(i+lib_top));line(p->x,y,b);
  }
 }else{
  WORD bx=p->x+6,by=p->y+4,bh=maxi(18,ch+6),gap=4,bw;
  bw=(p->w-12-gap*(QUEUE_BUTTONS-1))/QUEUE_BUTTONS;
  if(bw>64)bw=64;
  for(i=0;i<QUEUE_BUTTONS;i++){
   WORD xx=bx+i*(bw+gap);
   if(xx+bw>p->x+p->w)break;
   fillrect(xx,by,bw,bh,WHITE);outline(xx,by,bw,bh);
   {const char *label=(i==3 && connected && lg_shuffle_mode())?"Rand":queue_buttons[i];
   put(xx+maxi(1,(bw-(WORD)strlen(label)*cw)/2),by+bh/2+ch/3,label);}
  }
  sprintf(b,"Playlist - %d tracks",connected?lg_queue_count():0);line(p->x,p->y+bh+6,b);
  for(i=0;i<queue_visible(p);i++){
   WORD is_current=(WORD)(connected && i+queue_top==lg_queue_index());
   y=p->y+bh+6+ch*(i+2);if(y+ch>p->y+p->t)break;
   if(!connected || !lg_queue(i)[0])continue;
   sprintf(b,"%c %.72s",is_current?'*':' ',lg_queue(i));
   line(p->x,y,b);
  }
 }
}
/* Progress repaint uses GEM's visible-rectangle list and clips to the
   graphical bar; it never erases text or other window contents. */
static void repaint_progress(void){
 PANE *p=&panes[0];WORD vx,vy,vw,vhgt,r[4],clip[4];
 wind_get(p->h,WF_WORKXYWH,&p->x,&p->y,&p->w,&p->t);
 player_geometry(p);
 wind_get(p->h,WF_FIRSTXYWH,&vx,&vy,&vw,&vhgt);
 while(vw>0&&vhgt>0){
  r[0]=maxi(bar_x,vx);r[1]=maxi(bar_y,vy);
  r[2]=mini(bar_x+bar_w,vx+vw);r[3]=mini(bar_y+bar_h,vy+vhgt);
  if(r[2]>r[0]&&r[3]>r[1]){
   clip[0]=r[0];clip[1]=r[1];clip[2]=r[2]-1;clip[3]=r[3]-1;
   vs_clip(vh,1,clip);progress_bar();
  }
  wind_get(p->h,WF_NEXTXYWH,&vx,&vy,&vw,&vhgt);
 }
 clip[0]=clip[1]=clip[2]=clip[3]=0;vs_clip(vh,0,clip);
}
static void repaint_pane(int n);
/* A native GEM modal alert allows browsing every LMS player without
   requiring an RSC file or a separate AES window. */
static void select_player(void){
 int count,index,answer;char alert[180];char label[42];
 count=lg_player_count();
 if(count<=0){form_alert(1,"[1][No LMS players found][OK]");return;}
 index=lg_player_current();
 for(;;){
  strncpy(label,lg_player_name(index),sizeof(label)-1);label[sizeof(label)-1]=0;
  /* GEM alert separators cannot appear inside a player name. */
  {int j;for(j=0;label[j];j++)if(label[j]=='|'||label[j]==']'||label[j]=='[')label[j]=' ';}
  sprintf(alert,"[1][Select LMS player|%d of %d: %.36s][Select|Next|Cancel]",index+1,count,label);
  answer=form_alert(1,alert);
  if(answer==3||answer<=0)break;
  if(answer==2){index=(index+1)%count;continue;}
  if(lg_player_select(index)==0){lg_refresh();repaint_pane(0);repaint_pane(1);repaint_pane(2);}
  break;
 }
}
static void player_click(WORD x,WORD y){
 int i;
 if(!connected)return;
 player_geometry(&panes[0]);
 if(y<ctl_y||y>=ctl_y+ctl_h)return;
 for(i=0;i<CONTROL_COUNT;i++)if(x>=ctl_x[i]&&x<ctl_x[i]+ctl_w){
  switch(i){
   case 0:select_player();return;
   case 1:lg_command("playlist index -1");break;
   case 2:lg_command("pause");break;
   case 3:lg_command("stop");break;
   case 4:lg_command("playlist index +1");break;
   case 5:lg_command("power 0");break;
   case 6:lg_command("mixer volume -5");break;
   case 7:lg_command("mixer volume +5");break;
   case 8:lg_repeat((lg_repeat_mode()+1)%3);break;
  }
  if(lg_refresh()==0){repaint_pane(0);if((i>=1&&i<=5)||i==8)repaint_pane(2);}
  return;
 }
}
static void repaint_pane(int n);
static void playlist_click(WORD x,WORD y){
 PANE *p=&panes[2];WORD bx=p->x+6,by=p->y+4,bh=maxi(18,ch+6);
 WORD gap=4,bw;int i;
 if(!connected)return;
 if(y>=p->y+bh+6+ch*2+4){
  int row=(y-(p->y+bh+6)-4)/ch-2;
  int absolute=queue_top+row;
  char cmd[40];
  if(row>=0&&row<queue_visible(p)&&absolute>=0&&absolute<lg_queue_count()&&lg_queue(row)[0]){
   sprintf(cmd,"playlist index %d",absolute);
   lg_command(cmd);
   if(lg_refresh()==0){repaint_pane(0);repaint_pane(2);}
  }
  return;
 }
 if(y<by||y>=by+bh)return;
 bw=(p->w-12-gap*(QUEUE_BUTTONS-1))/QUEUE_BUTTONS;
 if(bw>64)bw=64;
 for(i=0;i<QUEUE_BUTTONS;i++){
  WORD xx=bx+i*(bw+gap);
  if(x<xx||x>=xx+bw||xx+bw>p->x+p->w)continue;
  if(i==0)lg_command("playlist index -1");
  else if(i==1)lg_command("playlist index +1");
  else if(i==2){if(form_alert(1,"[2][Clear the current playlist?][Clear|Cancel]")==1)lg_clear();else return;}
  else if(i==3)lg_shuffle();
  else return;
  if(lg_refresh()==0){repaint_pane(0);repaint_pane(2);}
  return;
 }
}
static void library_click(WORD x,WORD y){
 PANE *p=&panes[1];WORD bx=p->x+6,by=p->y+4,bh=maxi(17,ch+4);
 WORD bw,gap=2;int idx,row,sel;
 if(!connected)return;
 if(y>=by&&y<by+bh*2+4){
  library_click_armed=-1;
  bw=(p->w-12-gap*(NAV_COUNT-1))/NAV_COUNT;if(bw>40)bw=40;if(bw<10)bw=10;
  idx=(x-bx)/(bw+gap);
  if(x<bx||idx<0||idx>=NAV_COUNT||x>=bx+idx*(bw+gap)+bw)return;
  if(y<by+bh){
   switch(idx){
    case 0:lg_browser_back();break;
    case 1:if(lg_browser_is_root()&&lg_browser_selected()==6)search_dialog();else{lg_browser_activate(0);lg_refresh();repaint_pane(0);repaint_pane(2);}break;
    case 2:lg_browser_move(10);break;
    case 3:lg_browser_move(1);break;
    case 4:lg_browser_move(-1);break;
    case 5:lg_browser_move(-10);break;
    case 6:lg_browser_activate(1);lg_refresh();repaint_pane(0);repaint_pane(2);break;
    case 7:lg_browser_add_all();lg_refresh();repaint_pane(0);repaint_pane(2);break;
   }
  }else if(y>=by+bh+4){lg_browser_jump(jump_letter[idx]);}
  repaint_pane(1);return;
 }
 row=(y-(p->y+LIB_TOOL_H)-4)/ch-2;
 if(row>=0&&row+lib_top<lg_browser_count()&&row<library_visible(p)&&
    y>=p->y+LIB_TOOL_H+ch*(row+2)+4 &&
    y<p->y+LIB_TOOL_H+ch*(row+3)+4){
  sel=lg_browser_selected();
  if(1){
   library_click_armed=-1;
   if(row+lib_top!=sel)lg_browser_move(row+lib_top-sel);
   if(strcmp(lg_browser_item(row+lib_top),"Search")==0 && lg_browser_is_root())search_dialog();
   else {lg_browser_activate(0);lg_refresh();repaint_pane(0);repaint_pane(2);}
  }else{
   lg_browser_move(row+lib_top-sel);
   library_click_armed=lg_browser_selected();
  }
  repaint_pane(1);
 }
}
static void redraw(int n,WORD x,WORD y,WORD w,WORD h){
 WORD r[4],a[4],vx,vy,vw,vhgt;PANE *p=&panes[n];
 wind_get(p->h,WF_FIRSTXYWH,&vx,&vy,&vw,&vhgt);
 while(vw>0&&vhgt>0){
  r[0]=maxi(x,vx);r[1]=maxi(y,vy);r[2]=mini(x+w,vx+vw);r[3]=mini(y+h,vy+vhgt);
  if(r[2]>r[0]&&r[3]>r[1]){a[0]=r[0];a[1]=r[1];a[2]=r[2]-1;a[3]=r[3]-1;vs_clip(vh,1,a);render(n);}
  wind_get(p->h,WF_NEXTXYWH,&vx,&vy,&vw,&vhgt);
 }
 a[0]=a[1]=a[2]=a[3]=0;vs_clip(vh,0,a);
}
static void repaint_pane(int n){if(n>0)update_slider(n);redraw(n,panes[n].x,panes[n].y,panes[n].w,panes[n].t);}
static void repaint(void){int i;for(i=0;i<3;i++)repaint_pane(i);}
static void keypress(WORD key){int ascii=key&255,scan=(key>>8)&255;
 int changed=0, player=0, queue=0, browser=0;
 if(ascii==27){running=0;return;}
 if(scan==59){form_alert(1,"[1][LMS-GEM stage 5|Graphical player][OK]");return;}
 if(!connected)return;
 if(scan==72){lg_browser_move(-1);browser=1;}
 else if(scan==80){lg_browser_move(1);browser=1;}
 else if(scan==73){lg_browser_page(-1);browser=1;}
 else if(scan==81){lg_browser_page(1);browser=1;}
 else if(scan==75||ascii==8){lg_browser_back();browser=1;}
 else if(ascii==13){if(lg_browser_is_root()&&lg_browser_selected()==6)search_dialog();else{lg_browser_activate(0);changed=1;}browser=1;}
 else if(ascii>='A'&&ascii<='Z'){lg_browser_jump(ascii);browser=1;}
 else switch(ascii){
 case ' ':lg_command("pause");changed=1;break;
 case 's':lg_command("stop");changed=1;break;
 case 'n':lg_command("playlist index +1");changed=1;break;
 case 'b':lg_command("playlist index -1");changed=1;break;
 case '+':case '=':lg_command("mixer volume +5");changed=1;break;
 case '-':lg_command("mixer volume -5");changed=1;break;
 case 'a':lg_browser_activate(1);changed=1;browser=1;break;
 case 'c':lg_clear();changed=1;break;
 case 'x':lg_shuffle();changed=1;break;
 case '0':lg_repeat(0);changed=1;break;
 case '1':lg_repeat(1);changed=1;break;
 case '2':lg_repeat(2);changed=1;break;
 case 'p':select_player();return;
 case 'r':changed=1;browser=1;break;
 default:return;
 }
 if(changed){lg_refresh();player=1;queue=1;}
 if(player)repaint_pane(0);
 if(browser)repaint_pane(1);
 if(queue)repaint_pane(2);
}
WORD GEMAIN(WORD argc,char *argv[]){
 WORD in[11],out[57],i,event,msg[8];
 UWORD mx,my,buttons,shifts,key,clicks;
 WORD px[3],py[3],pw[3],ph[3],f[4];int n,rc;
 (void)argc;(void)argv;
 if(appl_init(NULL)<0)return 1;
 vh=graf_handle(&cw,&ch,&bw,&bh);for(i=0;i<10;i++)in[i]=1;in[10]=2;v_opnvwk(in,&vh,out);
 setup_menu(out[0]+1,out[1]+1);menu_bar(menu_tree,TRUE);
 wind_get(0,WF_WORKXYWH,&deskx,&desky,&deskw,&deskh);
 px[0]=deskx+4;py[0]=desky+4;pw[0]=deskw-8;ph[0]=maxi(90,deskh/3);
 px[1]=deskx+4;py[1]=desky+ph[0]+4;pw[1]=deskw/2-5;ph[1]=deskh-ph[0]-8;
 px[2]=deskx+deskw/2;py[2]=py[1];pw[2]=deskw/2-4;ph[2]=ph[1];
 for(i=0;i<3;i++){
  panes[i].h=wind_create(KIND,deskx,desky,deskw,deskh);
  if(panes[i].h<0){running=0;break;}
  wind_set(panes[i].h,WF_NAME,OFF(names[i]),SEG(names[i]),0,0);
  wind_open(panes[i].h,px[i],py[i],pw[i],ph[i]);
  wind_get(panes[i].h,WF_WORKXYWH,&panes[i].x,&panes[i].y,&panes[i].w,&panes[i].t);
 }
 graf_mouse(ARROW,0L);
 if(running){rc=lg_init(NULL,0);if(rc==0){connected=1;lg_refresh();queue_top=maxi(0,lg_queue_index()-2);lg_queue_window(queue_top);}else{
  form_alert(1,"[1][LMS connection failed|Check LMSGEM.CFG and MTCPCFG|Use SERVER= and PORT=][OK]");
 }}
 repaint();
 while(running){
  event=evnt_multi(MU_MESAG|MU_KEYBD|MU_BUTTON|MU_TIMER,1,1,1,
   0,0,0,0,0,0,0,0,0,0,msg,250,0,&mx,&my,&buttons,&shifts,&key,&clicks);
  if(event&MU_KEYBD){library_click_armed=-1;keypress(key);}
  if(event&MU_TIMER){if(connected){lg_tick();if(++ticks>=12){int update;ticks=0;update=lg_poll_player();if(update==1)repaint_progress();else if(update==2){if(lg_refresh()==0){queue_top=maxi(0,lg_queue_index()-2);lg_queue_window(queue_top);repaint_pane(0);repaint_pane(2);}else repaint_progress();}}}}
  if(event&MU_BUTTON){
   for(n=0;n<3;n++)if(mx>=panes[n].x&&mx<panes[n].x+panes[n].w&&my>=panes[n].y&&my<panes[n].y+panes[n].t){
    active=n;
    if(n==0)player_click(mx,my);
    if(n==1&&connected)library_click(mx,my);
    if(n==2&&connected)playlist_click(mx,my);
   }
  }
  if(event&MU_MESAG){
   if(msg[0]==MN_SELECTED){
    if(msg[3]==3&&(msg[4]==1||msg[4]==6))show_about();
    menu_tnormal(menu_tree,msg[3],TRUE);
   }
   n=-1;for(i=0;i<3;i++)if(panes[i].h==msg[3])n=i;
   if(n>=0)switch(msg[0]){
    case WM_REDRAW:redraw(n,msg[4],msg[5],msg[6],msg[7]);break;
    case WM_ARROWED:
     if(n>0){int d=0;
      if(msg[4]==0)d=-maxi(1,n==1?library_visible(&panes[1]):queue_visible(&panes[2]));
      else if(msg[4]==1)d=maxi(1,n==1?library_visible(&panes[1]):queue_visible(&panes[2]));
      else if(msg[4]==2)d=-1;
      else if(msg[4]==3)d=1;
      if(d)scroll_pane(n,d);
     }break;
    case WM_VSLID:
     if(n>0){int total=n==1?lg_browser_count():lg_queue_count();
      int vis=n==1?library_visible(&panes[1]):queue_visible(&panes[2]);
      int dest=(int)((long)maxi(0,total-vis)*msg[4]/1000);
      scroll_pane(n,dest-(n==1?lib_top:queue_top));
     }break;
    case WM_TOPPED:wind_set(panes[n].h,WF_TOP,0,0,0,0);active=n;break;
    case WM_CLOSED:running=0;break;
    case WM_MOVED:case WM_SIZED:
     wind_set(panes[n].h,WF_CURRXYWH,msg[4],msg[5],msg[6],msg[7]);
     wind_get(panes[n].h,WF_WORKXYWH,&panes[n].x,&panes[n].y,&panes[n].w,&panes[n].t);redraw(n,panes[n].x,panes[n].y,panes[n].w,panes[n].t);break;
    case WM_FULLED:wind_get(0,WF_WORKXYWH,&f[0],&f[1],&f[2],&f[3]);wind_set(panes[n].h,WF_CURRXYWH,f[0],f[1],f[2],f[3]);
     wind_get(panes[n].h,WF_WORKXYWH,&panes[n].x,&panes[n].y,&panes[n].w,&panes[n].t);redraw(n,panes[n].x,panes[n].y,panes[n].w,panes[n].t);break;
   }
  }
 }
 menu_bar(menu_tree,FALSE);
 if(connected)lg_close();for(i=0;i<3;i++)if(panes[i].h>=0){wind_close(panes[i].h);wind_delete(panes[i].h);}
 v_clsvwk(vh);appl_exit();return 0;
}
